import React, {Component} from 'react';

import '../component3.css';

class CourseDisplay extends Component {
    constructor(props) {
      super(props);
      this.state = {
          }
    }

    render () {
        return (
            <div className="container-Fluid">
                <br />
                <div className="row">
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <strong>Name</strong>
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <h5>{this.props.title}</h5>
                    </div>
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <strong>Teacher</strong>
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <h5>{this.props.teacher}</h5>
                    </div>
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <strong>Lectures</strong>
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <h5>{this.props.lectures}</h5>
                    </div>
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <strong>Credits</strong>
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <h5>{this.props.credits}</h5>
                    </div>
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <strong>Timings</strong>
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <h5>{this.props.timings}</h5>
                    </div>
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                </div>
                <div className="row">
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <strong>Number of students</strong>
                    </div>
                    <div className="col-md-4 col-sm-5 col-xs-6">
                    <h5>{this.props.students}</h5>
                    </div>
                    <div className="col-md-2 col-sm-1 col-xs-0">
                    </div>
                </div>
                <div className="row">
                    <button className='btn btn-danger' onClick={this.props.delete}>
                    Delete
                    </button>
                </div>
            </div>
        );
    }
}
    
export default CourseDisplay;